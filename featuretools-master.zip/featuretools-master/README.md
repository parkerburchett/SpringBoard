# featuretools
Adapted exercise from here: https://github.com/Featuretools/predict-customer-churn/blob/master/churn/3.%20Feature%20Engineering.ipynb

Here is a video showing how to run the tutorial in colab or in a python env on your machine.

[Youtube Video](https://youtu.be/EUhOAX-0Mw0)
